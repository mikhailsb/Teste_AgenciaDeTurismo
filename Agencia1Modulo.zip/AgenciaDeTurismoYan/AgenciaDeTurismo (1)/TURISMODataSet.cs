﻿namespace AgenciaDeTurismo
{


    partial class TURISMODataSet
    {
    }
}

namespace AgenciaDeTurismo.TURISMODataSetTableAdapters {
    
    
    public partial class ReservaTableAdapter {

    }
}
