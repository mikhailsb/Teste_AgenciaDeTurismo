﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgenciaDeTurismo
{
    public partial class frmMenuPrincipal : Form
    {
        public frmMenuPrincipal()
        {
            InitializeComponent();
        }

        private void btnCadastroFunc_Click(object sender, EventArgs e)
        {
            frmCadastroFuncionario funcionario = new frmCadastroFuncionario();
            funcionario.Show();

            this.Visible = false;
        }

        private void btnCadastroCliente_Click(object sender, EventArgs e)
        {
            frmCadastroCliente cliente = new frmCadastroCliente();
            cliente.Show();

            this.Visible = false;

        }

        private void btnCadastroPacotes_Click(object sender, EventArgs e)
        {
            frmCadastroPacotes pacotes = new frmCadastroPacotes();
            pacotes.Show();

            this.Visible = false;
        }

        private void funciónarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCadastroFuncionario funcionario = new frmCadastroFuncionario();
            funcionario.Show();

            this.Visible = false;
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCadastroCliente cliente = new frmCadastroCliente();
            cliente.Show();

            this.Visible = false;
        }

        private void pacotesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCadastroPacotes pacotes = new frmCadastroPacotes();
            pacotes.Show();

            this.Visible = false;
        }

        private void btnConsultasCadastros_Click(object sender, EventArgs e)
        {
            frmConsultaCadastro cadastros = new frmConsultaCadastro();
            cadastros.Show();

            this.Visible = false;
        }

        private void btnConsultasReservas_Click(object sender, EventArgs e)
        {
            frmConsultaReserva reserva = new frmConsultaReserva();
            reserva.Show();

            this.Visible = false;
        }

        private void cadastrosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmConsultaCadastro cadastros = new frmConsultaCadastro();
            cadastros.Show();

            this.Visible = false;
        }

        private void reservasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConsultaReserva reservas = new frmConsultaReserva();
            reservas.Show();

            this.Visible = false;
        }

        private void frmMenuPrincipal_Load(object sender, EventArgs e)
        {
            lblData.Text = DateTime.Now.ToString("dd/MM/yyyy");
        }

        private void tmrHora_Tick(object sender, EventArgs e)
        {
            lblHora.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            frmLogin login = new frmLogin();
            login.Show();

            this.Visible = false;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            frmConsultaVenda consVenda = new frmConsultaVenda();
            consVenda.Show();

            this.Visible = false;
        }

        private void BtnAgendaReservas_Click(object sender, EventArgs e)
        {
            frmAgendaReserva reserva = new frmAgendaReserva();
            reserva.Show();

            this.Visible = false;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            frmPagamento pagamento = new frmPagamento();
            pagamento.Show();

            this.Visible = false;
        }

        private void BtnConsultaPagamento_Click(object sender, EventArgs e)
        {
            frmConsultaPagamento consPagamento = new frmConsultaPagamento();
            consPagamento.Show();

            this.Visible = false;
        }

        private void GbDataHora_Enter(object sender, EventArgs e)
        {

        }

        private void BtnConfigCor_Click(object sender, EventArgs e)
        {

            movePnl(btnConfigCor);

            if (this.BackColor == Color.FromArgb(224, 224, 224) && panel5.BackColor == Color.FromArgb(46, 66, 80))
            {
                this.BackColor = Color.FromArgb(46, 66, 80);
                panel5.BackColor = Color.FromArgb(255, 255, 255);
                btnCadastroCliente.BackColor = Color.FromArgb(100, 200, 255);
                btnCadastroFunc.BackColor = Color.FromArgb(100, 200, 255);
                btnCadastroPacotes.BackColor = Color.FromArgb(100, 200, 255);
                btnAgendaReservas.BackColor = Color.FromArgb(100, 200, 255);
                btnConsultaPagamento.BackColor = Color.FromArgb(100, 200, 255);
                btnConsultasCadastros.BackColor = Color.FromArgb(100, 200, 255);
                btnConsultasReservas.BackColor = Color.FromArgb(100, 200, 255);
                btnConsultVenda.BackColor = Color.FromArgb(100, 200, 255);
                btnPagamento.BackColor = Color.FromArgb(100, 200, 255);
                btnSair.BackColor = Color.FromArgb(100, 200, 255);
                btnConfigCor.BackColor = Color.FromArgb(100, 200, 255);
                btnMenuAgenda.BackColor = Color.FromArgb(100, 200, 255);
                btnMenuCadastros.BackColor = Color.FromArgb(100, 200, 255);
                btnMenuCons.BackColor = Color.FromArgb(100, 200, 255);
                btnMenuPag.BackColor = Color.FromArgb(100, 200, 255);
                pnlConsultas.BackColor = Color.FromArgb(100, 200, 255);
                label2.ForeColor = Color.FromArgb(100, 200, 255);
                label3.ForeColor = Color.FromArgb(100, 200, 255);
                label4.ForeColor = Color.FromArgb(100, 200, 255);
                label5.ForeColor = Color.FromArgb(100, 200, 255);
                label6.ForeColor = Color.FromArgb(100, 200, 255);
                label7.ForeColor = Color.FromArgb(100, 200, 255);
                label8.ForeColor = Color.FromArgb(100, 200, 255);
                label9.ForeColor = Color.FromArgb(100, 200, 255);
                label10.ForeColor = Color.FromArgb(100, 200, 255);
                panel3.BackColor = Color.FromArgb(100, 200, 255);
                panel2.BackColor = Color.FromArgb(100, 200, 255);
                gbDataHora.ForeColor = Color.FromArgb(100, 200, 255);
            }
            else
            {
                if (this.BackColor == Color.FromArgb(46, 66, 80) && panel5.BackColor == Color.FromArgb(255, 255, 255))
                {
                    this.BackColor = Color.FromArgb(224, 224, 224);
                    panel5.BackColor = Color.FromArgb(46, 66, 80);
                    btnCadastroCliente.BackColor = Color.FromArgb(46, 66, 91);
                    btnCadastroFunc.BackColor = Color.FromArgb(46, 66, 91);
                    btnCadastroPacotes.BackColor = Color.FromArgb(46, 66, 91);
                    btnAgendaReservas.BackColor = Color.FromArgb(46, 66, 91);
                    btnConsultaPagamento.BackColor = Color.FromArgb(46, 66, 91);
                    btnConsultasCadastros.BackColor = Color.FromArgb(46, 66, 91);
                    btnConsultasReservas.BackColor = Color.FromArgb(46, 66, 91);
                    btnConsultVenda.BackColor = Color.FromArgb(46, 66, 91);
                    btnPagamento.BackColor = Color.FromArgb(46, 66, 91);
                    btnSair.BackColor = Color.FromArgb(46, 66, 91);
                    btnConfigCor.BackColor = Color.FromArgb(46, 66, 91);
                    btnMenuAgenda.BackColor = Color.FromArgb(46, 66, 91);
                    btnMenuCadastros.BackColor = Color.FromArgb(46, 66, 91);
                    btnMenuCons.BackColor = Color.FromArgb(46, 66, 91);
                    btnMenuPag.BackColor = Color.FromArgb(46, 66, 91);
                    pnlConsultas.BackColor = Color.FromArgb(46, 66, 91);
                    label2.ForeColor = Color.FromArgb(46, 66, 91);
                    label3.ForeColor = Color.FromArgb(46, 66, 91);
                    label4.ForeColor = Color.FromArgb(46, 66, 91);
                    label5.ForeColor = Color.FromArgb(46, 66, 91);
                    label6.ForeColor = Color.FromArgb(46, 66, 91);
                    label7.ForeColor = Color.FromArgb(46, 66, 91);
                    label8.ForeColor = Color.FromArgb(46, 66, 91);
                    label9.ForeColor = Color.FromArgb(46, 66, 91);
                    label10.ForeColor = Color.FromArgb(46, 66, 91);
                    panel3.BackColor = Color.FromArgb(46, 66, 91);
                    panel2.BackColor = Color.FromArgb(46, 66, 91);
                    gbDataHora.ForeColor = Color.FromArgb(46, 66, 91);
                }
            }

        }

        private void LblCadastros_Click(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void CadastrosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ReservasToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmAgendaReserva reserva = new frmAgendaReserva();
            reserva.Show();

            this.Visible = false;
        }

        private void SairToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void PagamentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConsultaPagamento consPag = new frmConsultaPagamento();
            consPag.Show();

            this.Visible = false;
        }

        private void VendaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConsultaVenda consVenda = new frmConsultaVenda();
            consVenda.Show();

            this.Visible = false;
        }

        private void PagamentoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmPagamento pagamento = new frmPagamento();
            pagamento.Show();

            this.Visible = false;
        }

        private void LblData_Click(object sender, EventArgs e)
        {

        }

        private void Button4_Click(object sender, EventArgs e)
        {

        }

        private void movePnl(Control btn)
        {
            pnlSlide.Width = btn.Width;
            pnlSlide.Left = btn.Left;
        }

        private void BtnMenuCadastros_MouseEnter(object sender, EventArgs e)
        {
            pnlCadastros.Visible = false;
        }

        private void BtnMenuCadastros_MouseHover(object sender, EventArgs e)
        {
            pnlCadastros.Visible = true;
        }

        private void PnlCadastros_MouseLeave(object sender, EventArgs e)
        {
            pnlCadastros.Visible = true;
        }

        private void PnlCadastros(object sender, PaintEventArgs e)
        {

        }

        private void BtnMenuCadastros_Click(object sender, EventArgs e)
        {
            movePnl(btnMenuCadastros);
        }

        private void BtnMenuAgenda_Click(object sender, EventArgs e)
        {

            movePnl(btnMenuAgenda);
        }

        private void BtnMenuPag_Click(object sender, EventArgs e)
        {

            movePnl(btnMenuPag);
        }

        private void BtnMenuCons_Click(object sender, EventArgs e)
        {

            movePnl(btnMenuCons);
        }

        private void PnlConsultas_Paint(object sender, PaintEventArgs e)
        {
            pnlConsultas.Visible = true;
        }

        private void Button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnMenuCor_Click(object sender, EventArgs e)
        {

        }

        private void Button2_Click_1(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void PnlSlide_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnMenuCadastros_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnMenuAgenda_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnMenuAgenda_MouseEnter(object sender, EventArgs e)
        {
            pnlAgenda.Visible = false;
        }

        private void BtnMenuAgenda_MouseHover(object sender, EventArgs e)
        {
            pnlAgenda.Visible = true;
        }

        private void PnlAgenda_MouseLeave(object sender, EventArgs e)
        {
            pnlAgenda.Visible = true;
        }

        private void PnlAgenda_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnMenuPag_Paint(object sender, PaintEventArgs e)
        {

        }

        private void PnlPagamento_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnMenuPag_MouseEnter(object sender, EventArgs e)
        {
            pnlPagamento.Visible = false;
        }

        private void BtnMenuPag_MouseHover(object sender, EventArgs e)
        {
            pnlPagamento.Visible = true;
        }

        private void PnlPagamento_MouseLeave(object sender, EventArgs e)
        {
            pnlPagamento.Visible = true;
        }

        private void BtnMenuCons_MouseEnter(object sender, EventArgs e)
        {
            pnlConsultas.Visible = false;
        }

        private void BtnMenuCons_MouseHover(object sender, EventArgs e)
        {
            pnlConsultas.Visible = true;
        }
    }
}
