CREATE DATABASE TURISMO
USE TURISMO

CREATE TABLE Login(
Usuario varchar (10) primary key,
Senha varchar (8),
Nome varchar (20),
)
select*from Login
insert into Login values ('admin','12345','Admin')

CREATE TABLE Cliente(
Cod_Cliente int primary key identity,
Nome_Cliente varchar (50),
Data_Nascimento date,
Telefone_Cliente varchar (20),
Nacionalidade varchar(20),
CPF_Cliente varchar (20),
Email_cliente varchar (150)
)
insert into Cliente values ('jn2', '120202', '31', 'gdfg', '300021', 'fefre@bfgbfb')
select*from Cliente

CREATE TABLE Funcionario(
Cod_Funcionario int primary key identity,
Nome_Funcionario varchar (50),
Email_Funcionario varchar (150),
Telefone_Funcionario varchar (20),
CPF_Funcionario varchar (20),
)
select*from Funcionario

CREATE TABLE Pacotes(
Cod_Pacote int primary key identity,
Tipo_Pacote varchar (40),
Origem varchar (40),
Destino varchar (40),
Quant_Passagem int,
Desc_Pacote varchar (150),
Valor_Pacote varchar (20), <--Valor unit�rio-->
)
select*from Pacotes

<-- avari�vel valor_total n�o ser� necess�ria->
<--Como fazer a multiplica��o de quant_Passagem por valor unit�rio?-->


CREATE TABLE Reserva(
Cod_Reserva int primary key identity,
Cod_Pacote int foreign key (Cod_Pacote) references Pacotes (Cod_Pacote),
Cod_Cliente int foreign key (Cod_Cliente) references Cliente (Cod_Cliente),
Nome_Titular varchar (50),
Data_Reserva date, 
Data_Final date
)

insert into Reserva values (1, 2, 'Teste', '020202', '030303')
insert into Reserva values ('121212', '12120', 1, 2)
insert into Reserva values ('010201', 'teste', 1, 2, '020202')
select*from Reserva
<--Adicionei "Data_Final' date-->



CREATE TABLE Pagamento(
Cod_Pagamento int primary key identity,
Cod_Reserva int foreign key (Cod_Reserva) references Reserva (Cod_Reserva)
Tipo_Pagamento varchar (20),
Valor_Total varchar (20),
Nome_Titular varchar (20),
Numero_Cartao varchar (25),
Data_Validade varchar (10),
Cod_Seguranca varchar (10)
)

insert into Pagamento values (3, 'Boleto', '200', 'Teste', '-', '-', '-')
select*from Pagamento
<--Removi o n�mero de parcelas e mudei o tipo de dado do cod de seguran�a-->

CREATE TABLE Venda(
Cod_Venda int primary key identity,
Cod_Pagamento int,
Cod_Cliente int,
Cod_Pacotes int,
Data_Venda date,
Cod_Funcionario int,
constraint fk_Cod_Pagamento foreign key (Cod_Pagamento) references Pagamento (Cod_Pagamento),
constraint fk_Cod_Cliente foreign key (Cod_Cliente) references Cliente (Cod_Cliente),
constraint fk_Cod_Pacotes foreign key (Cod_Pacotes) references Pacotes (Cod_Pacote),
constraint fk_Cod_Funcionarios foreign key (Cod_Funcionario) references Funcionario (Cod_Funcionario),
)

select Cod_Venda, Nome_Funcionario, P.Nome_Titular, L.Nome_Cliente, S.Destino, Data_Venda from Venda VJOIN Funcionario F
on V.Cod_Funcionario = F.Cod_Funcionario
INNER JOIN Pagamento P
on V.Cod_Pagamento = P.Cod_Pagamento
INNER JOIN Cliente L
on V.Cod_Cliente = L.Cod_Cliente
INNER JOIN Pacotes S
on V.Cod_Pacotes = S.Cod_Pacote
select * from Venda


select Cod_Venda, Cod_Funcionario, Cod_Pagamento, Cod_Cliente, Cod_Pacotes, Data_Venda from Venda <--Usamos o SELECT para colocar a ordem que queremos-->
insert into Venda (Cod_Pagamento, Cod_Cliente, Cod_Pacotes, Data_Venda, Cod_Funcionario) values ()

SELECT Pagamento.Cod_Pagamento, Reserva.Cod_Cliente, Reserva.Cod_Pacote FROM Pagamento
INNER JOIN Reserva
on Pagamento.Cod_Reserva = Reserva.Cod_Reserva
WHERE Pagamento.Cod_Pagamento in (SELECT MAX(Cod_Pagamento) FROM Pagamento);


CREATE TABLE Convenio(
Cod_Convenio int primary key identity,
Nome_Convenio varchar (50),
Tipo_Convenio varchar (50),
Descricao varchar (50),
)
select*from Convenio

SELECT Cod_Reserva, Data_Reserva, Nome_Titular, Cod_Pacote, Cod_Cliente FROM dbo.Reserva
WHERE Cod_Reserva NOT IN (SELECT Cod_Reserva FROM Pagamento);

SELECT PAGAMENTO.Cod_Pagamento, RESERVA.Cod_Reserva FROM PAGAMENTO
INNER JOIN RESERVA 
ON PAGAMENTO.Cod_Reserva = RESERVA.Cod_Reserva
WHERE PAGAMENTO.COD_PAGAMENTO = 10;



update Funcionario set Nome_Funcionario = 'A', Email_Funcionario = 'A', Telefone_Funcionario = 'A', CPF_Funcionario = 'A' where Cod_Funcionario = 2;
